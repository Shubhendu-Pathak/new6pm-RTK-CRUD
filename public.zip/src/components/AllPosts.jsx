import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { deleteUser, showUser } from '../store/thunk/fetchUser';
import Loader from './Loader';
import { useNavigate } from 'react-router-dom';

function AllPosts() {

let myuser= useSelector(state=>state.allusers)

// console.log(myuser)

let {data,isLoading,error} = myuser
console.log(data);

let onDel = (para)=>{
  console.log(para);
dispatch(deleteUser(para))
}

let nav = useNavigate()

let getprev = (para) =>{
nav(`/${para.id}`)
}

let editpost=(para)=>{
  // console.log(para);
  nav(`/edit/${para.id}`)
}


let dispatch = useDispatch()

useEffect(()=>{
  dispatch(showUser())
},[])


if(error){
  return <h1>{error.message}</h1>
}

if(isLoading===true){
  return <Loader/>
}

return (
<div>
{
    data && data?.map(ele=>{
      return <div  key={ele.id} className='border border-5 p-3 w-50 m-auto rounded-5 my-3 text-center text-bg-info text-white'>
        <img src={ele.image} alt=""  style={{height:"70px"}}/>
        <h5>{ele?.name}</h5>
        <h6>{ele?.email}</h6>
        <p className="lead fw-bolder fs-4">{ele.description.substr(0,20)}.....</p>
        <h2>Gender = {ele.gender}</h2>
        <div className=" p-3 d-flex justify-content-evenly">
          <button className='btn btn-warning' 
          onClick={()=>getprev(ele)}
          >Preview</button>
          <button 
          className='btn btn-warning'
          onClick={()=>editpost(ele)}
          >Edit</button>
          <button className='btn btn-warning'
          onClick={()=>onDel(ele)}
          >Delete</button>
        </div>
      </div>
    })
  }
</div>
)

}

export default AllPosts