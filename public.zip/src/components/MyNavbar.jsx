import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { NavLink } from 'react-router-dom';

function MyNavbar() {
  return (
    <Navbar expand="sm" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home">
          <img src="https://cdn-icons-png.flaticon.com/128/4290/4290854.png" alt="" style={{height:"40px"}} />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <NavLink className="fs-6 mx-3 fw-bolder text-info text-decoration-none" to="/">ALL-POST</NavLink>
            <NavLink className="fs-6 mx-3 fw-bolder text-info text-decoration-none" to="/createpost">CREATE-POST</NavLink>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default MyNavbar